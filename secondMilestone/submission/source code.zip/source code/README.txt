How to generate production dataset: run fillDatabase.py and readDatabaseFromReddit.py
The first puts the top 250 movies from imdb into the database.
The second searches for movies from r/movies subreddit. The respective URLs are included
in each script. 

The url to our site is the following:
	https://movie-suggestion-316.herokuapp.com/
Our git repo is the following:
	git@github.com:yuminz/316Spring2017.git
